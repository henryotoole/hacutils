# hacutils
Personal utility library. Short for Henryotoole's Ars Commoditas
